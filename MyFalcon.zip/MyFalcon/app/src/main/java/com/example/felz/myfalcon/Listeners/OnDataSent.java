package com.example.felz.myfalcon.Listeners;

public interface OnDataSent {

    void send(String tag ,String username, String password );
}
