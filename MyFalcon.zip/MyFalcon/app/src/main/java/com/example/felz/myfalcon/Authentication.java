package com.example.felz.myfalcon;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.felz.myfalcon.Auth_fragment.Login_fragment;
import com.example.felz.myfalcon.Auth_fragment.Register_Fragment;
import com.example.felz.myfalcon.Listeners.OnDataSent;

public class Authentication extends AppCompatActivity implements OnDataSent {

    private EditText login_usr, login_pwd, register_usr, register_pwd, register_email;
    private Button register_btn, login_btn;
    private TextView i_already_have, i_dont_have;

    SharedPreferences preferences;
    SharedPreferences.Editor preferenceEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);

        login_usr = findViewById(R.id.login_username);
        login_pwd = findViewById(R.id.login_password);
        register_usr = findViewById(R.id.register_username);
        register_pwd = findViewById(R.id.register_password);
        register_email = findViewById(R.id.register_email);
        register_btn = findViewById(R.id.register_button);
        login_btn = findViewById(R.id.login_button);
        i_already_have = findViewById(R.id.i_already_have_accnt);
        i_dont_have = findViewById(R.id.i_dont_have_account);

        preferences = getSharedPreferences("SP", Context.MODE_PRIVATE);
        preferenceEditor = preferences.edit();

        init();
    }

    @Override
    public void send(String tag, String username, String password) {
        if (tag.equals("i_already_have")){
            Login_fragment login_fragment = new Login_fragment();
            setFragment(new Login_fragment(), "login_fragment", true);
        }
        else if (tag.equals("i_dont_have")){
            Register_Fragment register_fragment = new Register_Fragment();
            setFragment(new Register_Fragment(), "register_fragment", true);
        }
        else if (tag.equals("mainActivity")){
            if (preferenceEditor != null){
                String usr = username.toString();
                String pwd = password.toString();

                if (usr.isEmpty()||pwd.isEmpty()){
                    Toast.makeText(this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    String usr_txt = this.preferences.getString(usr, "Username does not exist!!");
                    String pwd_txt = this.preferences.getString(pwd, "Password is incorrect!!");
                    if (preferenceEditor.equals(usr_txt)&&preferenceEditor.equals(pwd_txt)){
                        Intent intent = new Intent(Authentication.this, MainActivity.class);
                        startActivity(intent);
                    }
//                  getText.setText("Val:" + val);
                }
            }
        }
        else if(tag.equals("mainActivity_reg")){
            String key = username.toString();
            String val = password.toString();

            if(key.isEmpty()||val.isEmpty()){
                Toast.makeText(this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
                return;
            }
            else {
                preferenceEditor.putString(key,val);
                preferenceEditor.commit();
                Intent intent = new Intent(Authentication.this,MainActivity.class);
                startActivity(intent);
            }
        }
    }

    public void init(){
        Login_fragment login_fragment = new Login_fragment();
        setFragment(login_fragment, "login_fragment" ,false);
    }

    public void setFragment(Fragment fragment, String tag, boolean addToBackStack){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment, tag);

        if(addToBackStack){
            transaction.addToBackStack(tag);
        }

        transaction.commit();
    }

    private void savePreference(){

        String key = login_usr.getText().toString();
        String val = login_pwd.getText().toString();

        if(key.isEmpty()||val.isEmpty()){
            Toast.makeText(this, "Empty Fields!!", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            preferenceEditor.putString(key,val);
            preferenceEditor.commit();
        }
    }

}
